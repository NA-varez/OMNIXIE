#ifndef _FUNCONFIG_H
#define _FUNCONFIG_H

// Place configuration items here, you can see a full list in ch32fun/ch32fun.h
// To reconfigure to a different processor, update TARGET_MCU in the  Makefile

#define FUNCONF_TINYVECTOR 1

#define FUNCONF_USE_HSE 0
#define FUNCONF_USE_HSI 1

#endif // _FUNCONFIG_H

