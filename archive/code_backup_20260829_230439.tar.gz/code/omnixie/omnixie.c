// Copied from Ch32v003 blink example

#include "ch32fun.h"
#include <stdio.h>

// use defines to make more meaningful names for our GPIO pins
#define PIN_K PD6


int main()
{
	SystemInit();

	funGpioInitAll(); // Enable GPIOs
	
	funPinMode( PIN_K,     GPIO_Speed_10MHz | GPIO_CNF_OUT_PP ); // Set PIN_K to output

	while(1)
	{
		funDigitalWrite( PIN_K,     FUN_HIGH ); // Turn on PIN_K
		Delay_Ms( 250 );
		funDigitalWrite( PIN_K,     FUN_LOW );  // Turn off PIN_K
		Delay_Ms( 250 );
	}
}
